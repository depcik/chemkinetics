% TROE FALL-OFF REACTION CALCULATOR
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

function [F,Pr]=troeform(klow,khigh,M,alpha,Tthree,Tone,Ttwo,T)
% This function calculates the 'F' value for the FALL-OFF reaction.
if isempty(Ttwo)
    Fc=(1-alpha)*exp(-T/Tthree)+alpha*exp(-T/Tone);
else
    Fc=(1-alpha)*exp(-T/Tthree)+alpha*exp(-T/Tone)+exp(-Ttwo/T);
end
Pr=klow*M/khigh;
d=0.14; n=0.75-1.27*log10(Fc); c=-0.4-0.67*log10(Fc);
rhs1=log10(Pr)+c;
rhs2=(1+(rhs1/(n-d*rhs1))^2)^(-1);
rhs3=rhs2*log10(Fc);
F=10^rhs3;
end