% THERMODYNAMIC DATA EXTRACTOR
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

function consout=thermdatextractor2(species_folder,NM,species_order,T)
% This function extract the thermodynamic coefficients for the participating species. It requires a specific folder where the species data is stored in individual text files.
D = dir([species_folder,'\*.txt']); % Checks the number of files in the directory
thermcons_raw=cell(NM,1); % Initialize the cell array to store constants

cd(species_folder)
for i=1:NM
    [~,name,~]=fileparts(D(i).name); % Extracts for the file name
    [~,index]=ismember(name,species_order); % Checks whether the name is a member of the species list and finds its index in the list
    [fileID,~]=fopen(D(i).name,'r'); % Opens the file with read permission
    thermcons_raw(index)=textscan(fileID,'%f'); % Scans the data as text and saves in the appropriate index
end
fclose('all'); % Closes all files

NC=size(thermcons_raw{1,1},1); % Checks the size of each cell of the cell array and returns the largest dimension
thermcons_f=reshape(cell2mat(thermcons_raw),[NC,NM]); % Reshapes a cell array converted to matrix
thermcons_f=thermcons_f'; % Transpose of the matrix in the species order

if T<1000
    consout=thermcons_f(1:end,NC/2+1:end); % Saves the low constants
else
    consout=thermcons_f(1:end,1:NC/2); % Saves the high constants
end
cd ..

end