% THERMO-FIT CALCULATOR
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

function [Cpk,Hk,Sk,Gk]=thermofits3(T,constant,Ru,NM)
% This function calculates the thermodynamic properties for each species.
% The properties are expressed on a molar basis.
Cpkcoeff=[1;T;T^2;T^3;T^4;0;0];
Hkcoeff=[1;T/2;T^2/3;T^3/4;T^4/5;1/T;0];
Skcoeff=[log(T);T;T^2/2;T^3/3;T^4/4;0;1];

Cpk=zeros(NM,1); Hk=Cpk; Sk=Hk; Gk=Sk;
for i=1:NM
    Cp=0; H=0; S=0;
    for j=1:size(constant,2)
        Cp=Cp+constant(i,j)*Cpkcoeff(j);
        H=H+constant(i,j)*Hkcoeff(j);
        S=S+constant(i,j)*Skcoeff(j);
    end
    Cpk(i)=Cp*Ru;
    Hk(i)=H*Ru*T;
    Sk(i)=S*Ru;
    if T==298.15
        if (Hk(i)>0 && Hk(i)<10) || (Hk(i)>-1 && Hk(i)<0)
            Hk(i)=0;
        end
    end
    Gk(i)=Hk(i)-T*Sk(i);
end
end