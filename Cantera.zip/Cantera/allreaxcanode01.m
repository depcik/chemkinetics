% CANTERA ODE FILE
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

function dZdt=allreaxcanode01(t,IC)

% Declare global variables
global gas p0 patm Ru A alpha Ea eps_M n NM NR NR2 rxntype species ...
    species_folder Tone Tthree Ttwo v_p v_r vk Wk

%% Initial conditions (X0: Mole Fractions, T0: Temperature)
X0=IC(1:NM);
X0(9)=1-sum(X0(1:8))-sum(X0(10:11));
T0=IC(NM+1);

%% CANTERA OPERATIONS: Set the mixture conditions
setMoleFractions(gas,X0,'nonorm')
setTemperature(gas,T0)
setPressure(gas,p0)

%% Molar mass of gas mixture [g/mol]
Mmix=0;
for i=1:NM
    Mmix=Mmix+X0(i)*Wk(i);
end

%% Density calculation rhom = [mol/cm^3], rhoM = [kg/m^3]
rhom=p0/Ru/T0/1e6;
rhoM=p0*Mmix/Ru/T0/1000;

%% Mass fractions [-]
Y0=zeros(NM,1);
for i=1:NM
    Y0(i)=X0(i)*Wk(i)/Mmix;
end

%% Thermodynamic properties [molar basis] and reverse rate constant calculation
coefficients_T=thermdatextractor2(species_folder,NM,species,T0); % Extracts thermofit coefficients from the species file
[Cpk,Hk,Sk,Gk]=thermofits3(T0,coefficients_T,Ru,NM); % Calculates the properties using curvefits [J/mol.K, J/mol, J/mol.K]

%% Mixture averaged specific heat [J/mol.K]
Cpmix=0;
for i=1:NM
    Cpmix=Cpmix+Cpk(i)*X0(i);
end, clear i
CpmixM=1000*Cpmix/Mmix; % Mixture averaged specific heat [J/kg.K]

%% Enthalpy of species at standard state [J/kg]
HkM=zeros(NM,1);
for i=1:NM
    HkM(i)=Hk(i)/Wk(i)*1000;
end

%% Mixture averaged entropy [J/mol.K]
Skmix=0;
for i=1:NM
    if X0(i)~=0
        Skmix=Skmix+X0(i)*(Sk(i)-Ru*(log(X0(i)*p0/patm))); % Entropy of species [J/mol.K]
    end
end, clear i

%% Mixture averaged Gibbs free energy [J/mol]
Gkmix=0;
for i=1:NM
    if X0(i)~=0
        Gkmix=Gkmix+X0(i)*(Hk(i)-T0*(Sk(i)-Ru*(log(X0(i)*p0/patm)))); % Entropy of species [J/mol.K]
    end
end, clear i

%% Call Chemkin function for WdotM values [kg/m^3.s]
Wdot=netProdRates(gas); % Net production rate of species [kmol/m^3.s]
WdotM=zeros(NM,1);
for i=1:NM
    WdotM(i)=Wdot(i)*Wk(i);
end, clear i
disp(WdotM)

%% Mass frac ODE
dYdt=WdotM/rhoM;

%% Energy ODE
sum1=0;
for i=1:NM
    sum1=sum1-HkM(i)*WdotM(i)/rhoM/CpmixM;
end, clear i
dTdt=sum1; % Energy equation, temperature change with time [K/s]

%% Mole fraction ODE
dXdt=zeros(NM,1);
for j=1:NM
    sum2=0; sum3=0;
    for i=1:NM
        sum2=sum2+Y0(i)/Wk(i);
        sum3=sum3+dYdt(i)/Wk(i);
    end
    numer=dYdt(j)/Wk(j)*sum2-Y0(j)/Wk(j)*sum3;
    denom=sum2*sum2;
    dXdt(j)=numer/denom;
end

dZdt=[dXdt;dTdt];
end