% PREPARE STOICHIOMETRIC MATRICES
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

function [v_r,v_p,vk,NR2]=stoichiometricmatrix(NR,rxntype,txt)
% This function extracts the coefficients from each reaction and prepares the stoichiometric coefficient matrices for both reactancts and products.    
%% Extraction of reaction mechanism and parameters from imported reaction data
species2={'H2','H','O2','O','OH','HO2','H2O2','H2O','N2','AR','HE','M'}; % Includes the third body concentration as a "species"
rmechanism=cell(NR,1); % String of chemical reactions
v_r=zeros; v_p=v_r; % Initiate reactant and product stoichiometric matrices

%% Extract stoichiometric coefficients for reactant and products from listed chemical reactions
% MAGIC!
ii=1;
for i=1:NR
    if ismember(rxntype{i},{'S','T','L','D1','D2'}) % S: Simple, T: Three Body, L: TROE "Low", D'X': DUPLICATE
        rmechanism{i}=txt{i,1};
        split1=strsplit(rmechanism{i},'<=>');
        reactants=split1{1};
        products=split1{2};
        reactants=strsplit(reactants,'+');
        products=strsplit(products,'+');
        for j=1:length(reactants)
            nr=sscanf(reactants{j},'%d');
            if isempty(nr)
                nr=1;
                [~,indr]=ismember(reactants{j},species2);
            else
                specr=strsplit(reactants{j});
                [~,indr]=ismember(specr{2},species2);
            end
            v_r(ii,indr)=nr;
        end
        for j=1:length(products)
            np=sscanf(products{j},'%d');
            if isempty(np)
                np=1;
                [~,indp]=ismember(products{j},species2);
            else
                specp=strsplit(products{j});
                [~,indp]=ismember(specp{2},species2);
            end
            v_p(ii,indp)=np;
        end
        ii=ii+1;
    else
        continue
    end
end
% v_p and v_r are product and reactant stoichiometric coefficient matrices
vk=v_p-v_r; % Difference

NR2=size(vk,1);
end