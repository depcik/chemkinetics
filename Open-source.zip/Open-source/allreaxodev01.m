% OPEN-SOURCE ODE FILE
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

function dZdt=allreaxodev01(~,IC)
% The function dZdt = allreaxodev01(~,IC) solves the set of ODEs. The input
% variable "IC" follows a specific order with the first 11 entries being
% assigned to the species while the last entry is the temperature. Refer to
% the paper (ASME IMECE) for a direct comparison of the equations.

global p0 patm Ru A alpha Ea eps_M n NM NR NR2 rxntype species ...
    species_folder Tone Tthree Ttwo v_p v_r vk Wk

%% Initial conditions (X0: Mole Fractions, T0: Temperature)
X0=IC(1:NM);
X0(9)=1-sum(X0(1:8))-sum(X0(10:11));
T0=IC(NM+1);

%% Molar mass of gas mixture [g/mol]
Mmix=0;
for i=1:NM
    Mmix=Mmix+X0(i)*Wk(i);
end

%% Density calculation rhom = [mol/cm^3], rhoM = [kg/m^3]
rhom=p0/Ru/T0/1e6;
rhoM=p0*Mmix/Ru/T0/1000;

%% Specific gas constant [J/kg.K]
Rgas=Ru/Mmix*1000;

%% Mass fraction [-]
Y0=zeros(NM,1);
for i=1:NM
    Y0(i)=X0(i)*Wk(i)/Mmix;
end

%% Molar concentration of species [mol/cm^3]
Ck=zeros(NM,1);
for i=1:NM
    Ck(i)=rhom*X0(i);
end, clear i

%% Third body concentration [mol/cm^3]
M=zeros;
for j=1:size(eps_M,2)
    sumM=0; % [mol/cm^3] Molar concentration of colliding species in the gas mixture (without Argon partner)                                                                               
    for i=1:NM
        sumM=sumM+eps_M(i,j)*Ck(i);
    end
    M(j,1)=sumM;
end, clear i j

%% Forward reaction rate constant [originally in cm^3/mol.s]
kf=zeros;
i=1; ii=1; jj=size(eps_M,2);
while i<=NR
    karr=A(i)*T0^n(i)*exp(-Ea(i)/Ru/T0); % Arrhenius equation for reaction rate constant
    if strcmpi(rxntype{i},'S') % Simple reactions
        kf(ii,1)=karr;
        ii=ii+1;
    elseif strcmpi(rxntype{i},'T') % This IF statement treats the three body (dissociation-recombination) reactions only
        kf(ii,1)=karr*M(jj);
        ii=ii+1;
    elseif strcmpi(rxntype{i},'L') % Pressure dependent reactions
        if strcmpi(rxntype{i+1},'H')
            karr2=A(i+1)*T0^n(i+1)*exp(-Ea(i+1)/Ru/T0);
            khigh=karr;
            klow=karr2;
            [F,Pr]=troeform(klow,khigh,M(jj),alpha,Tthree,Tone,Ttwo,T0);
            kf(ii,1)=khigh*Pr/(1+Pr)*F;
            ii=ii+1;
            if jj~=0
                jj=jj-1;
            end
            i=i+1;
        else
            warning('Check pressure dependency reaction khigh')
            break;
        end
    elseif strcmpi(rxntype{i},'D1') || strcmpi(rxntype{i},'D2') % Duplicate reactions
        kf(ii,1)=karr;
        ii=ii+1;
    end
    i=i+1;
end, clear i ii

%% Thermodynamic properties [molar basis] and reverse rate constant calculation
coefficients_T=thermdatextractor2(species_folder,NM,species,T0); % Extracts thermofit coefficients from the species file
[Cpk,Hk,Sk,Gk]=thermofits3(T0,coefficients_T,Ru,NM); % Calculates the properties using curvefits [J/mol.K, J/mol, J/mol.K]

%% Mixture averaged specific heat [J/mol.K]
Cpmix=0;
for i=1:NM
    Cpmix=Cpmix+Cpk(i)*X0(i);
end, clear i
CpmixM=1000*Cpmix/Mmix; % Mixture averaged specific heat [J/kg.K]

%% Enthalpy of species at standard state [J/kg]
HkM=zeros(NM,1);
for i=1:NM
    HkM(i)=Hk(i)/Wk(i)*1000;
end

%% Mixture averaged entropy [J/mol.K]
Skmix=0;
for i=1:NM
    if X0(i)~=0
        Skmix=Skmix+X0(i)*(Sk(i)-Ru*(log(X0(i)*p0/patm))); % Entropy of species [J/mol.K]
    end
end, clear i

%% Mixture averaged Gibbs free energy [J/mol]
Gkmix=0;
for i=1:NM
    if X0(i)~=0
        Gkmix=Gkmix+X0(i)*(Hk(i)-T0*(Sk(i)-Ru*(log(X0(i)*p0/patm)))); % Entropy of species [J/mol.K]
    end
end, clear i

%% Calculation of change in Gibbs free energy in a reaction, equilibrium constants 'Kp' and 'Kc', and reverse rate constant 'kr'
init=zeros(NR2,1); dHi=init; dGi=init; Kp=init; Kc=init; kr=init;
for i=1:NR2
    dG=0; sumvk=0; dH=0;
    for j=1:NM
        dG=dG+vk(i,j)*Gk(j); % Standard gibbs free energy
        dH=dH+vk(i,j)*Hk(j); % Standard enthalpy of formation of species in a reaction
        sumvk=sumvk+vk(i,j); % This adds up an entire row of vk matrix and prepares an exponent term for Kc calculation
    end
    dGi(i)=dG; % Change in Gibbs free energy for a reaction        
    dHi(i)=dH; % Change in enthalpy of formation for a reaction         
    Kp(i)=exp(-dGi(i)/Ru/T0); % Equilibrium constant Kp [-]
    Kc(i)=Kp(i)*(patm/Ru/T0/1e6)^sumvk; % Equilibrium constant Kc is given in molar concentration units [mol/cm^3]
    kr(i)=kf(i)/Kc(i); % Reverse rate constant [cm^3/mol.s]
end, clear i j

%% Rate of progress 'q'
qf=init; qr=init; qnet=init;
for i=1:NR2
    mmm=1; nnn=1;
    for j=1:NM
        if v_r(i,j)~=0
            mmm=mmm*Ck(j)^v_r(i,j);
        end
        if v_p(i,j)~=0
            nnn=nnn*Ck(j)^v_p(i,j);
        end
    end
    qf(i)=kf(i)*mmm; % Forward rate of progress for a reaction [mol/cm^3.s]
    qr(i)=kr(i)*nnn; % Reverse rate of progress for a reaction [mol/cm^3.s]
    qnet(i)=qf(i)-qr(i); % Net rate of progress for a reaction [mol/cm^3.s]
end, clear i j

%% Rate of production or destruction of species WdotM [kg/cm^3.s]
Wdot=zeros(NM,1); WdotM=zeros(NM,1);
for i=1:NM
    wdotsum=0;
    for j=1:NR2
        wdotsum=wdotsum+vk(j,i)*qnet(j);
    end
    Wdot(i)=wdotsum; % Rate of production of a species [mol/cm^3.s]
    WdotM(i)=wdotsum*Wk(i)/1000; % Rate of production of a species [kg/cm^3.s]
end, clear i j
WdotM=WdotM*1e6; % [kg/m^3.s]
disp(WdotM)

%% Mass frac ODE
dYdt=WdotM/rhoM;

%% Energy ODE
sum1=0;
for i=1:NM
    sum1=sum1-HkM(i)*WdotM(i)/rhoM/CpmixM;
end, clear i
dTdt=sum1; % Energy equation, temperature change with time [K/s]

%% Mole fraction ODE
dXdt=zeros(NM,1);
for j=1:NM
    sum2=0; sum3=0;
    for i=1:NM
        sum2=sum2+Y0(i)/Wk(i);
        sum3=sum3+dYdt(i)/Wk(i);
    end
    numer=dYdt(j)/Wk(j)*sum2-Y0(j)/Wk(j)*sum3;
    denom=sum2*sum2;
    dXdt(j)=numer/denom;
end

dZdt=[dXdt;dTdt];
end