% IMPORT DATA FROM INPUT FILES AND PREPARE PRE-REQUISITES
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2018

function importonce()
% This function imports the data from an excel file and saves as a binary
% '.mat' file. It should be run only once before anything else.

%% Specify folder for using thermo coefficients
species_folder='Species';

%% Import reaction data from an Excel file
[num,txt,raw]=xlsread('reactions data new.xlsx');

rxntype=txt(:,5); % Specifies the reaction type, 's:simple; tbr:three body rxn; Low/High:pressure dependent rxn; Duplicate:duplicate reactions'
A=num(:,1); % Extracts column containing pre-exponential 'A'
n=num(:,2); % Extracts column containing exponent 'n'
Ea=num(:,3)*4.184*1e3; % Extracts column containing activation energy 'Ea' [J/mol]
NR=size(txt,1); % Number of reactions considered

[v_r,v_p,vk,NR2]=stoichiometricmatrix(NR,rxntype,txt);

%% Fall-off reaction parameters. See reference text for more information.
alpha=0.5;
Tthree=1e5;
Tone=10;
Ttwo=[];

%% Structure array for molecular weights of elements [g/mol]
Mw=struct(  'H',1.00796997547149,...
    'O',15.9994001388549,...
    'N',14.0066995620727,...
    'AR',39.9480018615722,...
    'HE',4.00260019302368);

%% Molecular weights of reacting species [g/mol]
Wk=[2*Mw.H;...
    Mw.H;...
    2*Mw.O;...
    Mw.O;...
    Mw.O+Mw.H;...
    Mw.H+2*Mw.O;...
    2*Mw.H+2*Mw.O;...
    2*Mw.H+Mw.O;...
    2*Mw.N;...
    Mw.AR;...
    Mw.HE];

%% Species data
species={
        'H2',...
        'H',...
        'O2',...
        'O',...
        'OH',...
        'HO2',...
        'H2O2',...
        'H2O',...
        'N2',...
        'AR',...
        'HE'
        };
NM=length(species); % Specifies the number of participating species

%% Chaperone efficiency data
eps_M=ones(NM,2); % Creates 2 parallel column vectors. First column is standard chaperone efficiency (=1). Second column is enhanced chaperone efficiency (for few species)
eps_M(1,2)=2.5; % Enhanced efficiency for H2
eps_M(8,2)=12.5; % Enhanced efficiency for H2O
eps_M(10,2)=0.75; % Enhanced efficiency for Ar

%% Enthalpy of formation of species [J/mol]
hf=[0; 52103; 0; 59550; 9318; 3000; -32530; -57795; 0; 0; 0]*4.184; % Standard enthalpy of formation [J/mol]

%% Save all data in a file that will called by the main driver file.
save alldata.mat
end