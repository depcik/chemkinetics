% OPEN-SOURCE DRIVER FILE
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

% Initialize workspace and editor!
clear;close all;clc;

% Record time at program initialization
tic

%% Check Matlab version for data plotting
matlabversioncheck=version('-release');
vernum=sscanf(matlabversioncheck,'%d'); % Extract the version number

%% Declare global variables
global p0 patm Ru A alpha Ea eps_M n NM NR NR2 rxntype species ...
    species_folder Tone Tthree Ttwo v_p v_r vk Wk

%% Import function loads all pre-requisite variables and values from text, dat, and/or excel files.
% importonce();
load alldata.mat % Loads the stoichiometric coefficients, reaction data, etc..

%% Inputs: Pressure, Temperature, Gas Constant
patm=101325; % [Pa]
p_exp=1; % Experimental pressure value [bar]
p0=p_exp*patm; % Initial pressure [Pa or J/m^3 for ease of cancellation]
Ru=8.314462175; % Universal gas constant [J/mol.K]
ntot=1; % Total number of moles of gas
T0=910; % Initial temperature [K]
V0=ntot*Ru*T0/p0; % Initial volume of gas [m^3]
    
%% Initial mole fractions [-]
% Species = 'H2','H','O2','O','OH','HO2','H2O2','H2O','N2','AR','HE'
XH2 = 0.00842;
XH = 0;
XO2 = 0.01052;
XO = 0;
XOH = 0;
XHO2 = 0;
XH2O2 = 0;
XH2O = 0;
XN2 = 1-XH2-XO2; % Balance
XAR = 0;
XHE = 0;
X0=[XH2;XH;XO2;XO;XOH;XHO2;XH2O2;XH2O;XN2;XAR;XHE];
% X0(9)=1-sum(X0(1:8))-sum(X0(10:11));
    
%% Initial conditions
atol=1e-12; rtol=1e-3; % Specify Absolute and Relative tolerances
options=odeset('AbsTol',ones(1,NM+1)*atol,'RelTol',rtol); % Specify ODE solver settings    
tmin=0; % Start time for simulation [s]
tmax=0.5; % End time for simulation [s]
t0=[tmin tmax]; % Initial time conditions
IC=[X0;T0]; % All initial conditions

%% Call ODE solver and ODE function
[t,out]=ode15s(@allreaxodev01,t0,IC,options);

%% Data plotting
figure
set(gcf,'units','normalized','position',[0 0.1 0.5 0.6])

if vernum<2016
    [AX,H1,H2]=plotyy(t,out(:,[1,2,3,8]),t,out(:,12));
    title({['Open-source @ ',num2str(p0),' Pa & ',num2str(T0),' K']})
    xlabel('Time [sec]','fontsize',12,'color','k','fontweight','bold')
    ylabel(AX(1),'Mole Fractions [-]','fontsize',12,'fontweight','bold') % Left axis
    ylabel(AX(2),'Temperature [K]','fontsize',12,'fontweight','bold') % Right axis
    set(H1(1),'linestyle','-','marker','o','color','b','linewidth',1)
    set(H1(2),'linestyle','-','marker','+','color','g','linewidth',1)
    set(H1(3),'linestyle','-','marker','*','color','r','linewidth',1)
    set(H1(4),'linestyle','-','marker','x','color','k','linewidth',1)
    set(H2(1),'linestyle','-.','marker','none','color','k','linewidth',2)
    legend('H_{2}','H','O_{2}','H_{2}O','Temperature','location','best')
else
    yyaxis left
    plot(t,out(:,1),'o-b',t,out(:,2),'+-g',t,out(:,3),'*-r',t,out(:,8),'x-k','linewidth',2)
    ylabel('Mole Fractions [-]','fontsize',12)
    yyaxis right
    plot(t,out(:,12),'k-','linewidth',2)
    title({['Open-source @ ',num2str(p0),' Pa & ',num2str(T0),' K'],'Mole Fractions and Temperature vs. Time'})
    xlabel('Time [sec]','fontsize',12,'color','k','fontweight','bold')
    ylabel('Temperature [K]','fontsize',12,'fontweight','bold')
    legend('H_{2}','H','O_{2}','H_{2}O','Temperature','location','best')
end
time2simulate=toc;
fprintf('Simulation time = %0.4f \r',time2simulate);