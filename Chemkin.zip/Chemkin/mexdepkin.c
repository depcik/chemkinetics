#include "mexdepkin.h"
#include "mex.h"

// Global Varaibles
char chemkinfile[1000];
char transfile[1000];
// Input Arguments
#define S0_IN	prhs[0]
#define S1_IN	prhs[1]
//#define S2_IN	prhs[2]
// This is the mexFunction call
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[]) {
	// nrhs = input arguments
	// nlhs = output arguments
	int NM;					// The number of species [-]
	int NREAC;				// Number of reactions [-]
	int LENICK;				// Length of the integer component of the chemkin file
	int LENRCK;				// Length of the real component of the chemkin file
	int LENCCK;				// Length of the name components of the chemkin file
	int LENIMC;				// Length of the integer component of the transport file
	int LENRMC;				// Length of the real component of the transport file
	int *ICKWRK;			// CHEMKIN integer array
	int *IMCWRK;			// Transport integer array
	double PR;				// Pressure in [Pa]
	double TP;				// Temperature in [K]
	double *RCKWRK;			// CHEMKIN double array
	double *RMCWRK;			// Transport double array
	double *YSP;			// Mass fraction of species input [-]
	double *CGDOT;			// The chemical production/destruction rates [kg/m3/s]
	double *FWDK;			// Forward reaction rates
	double *REVK;			// Reverse reaction rates
	double *GBMS;			// Gibbs free energies in [J/kg]
	double *GML;			// Gibbs free energies in [J/kmol]
	double *GMS;			// Gibbs free energies in [J/kg]
	double *EQKC;			// Equilibrium constants as [mole/cm^3]**power
	mwSize m, n;
	// Get the name of the chemkin file
	mxGetString(S0_IN, chemkinfile, 1000);
	// Get the name of the transport file
	mxGetString(S1_IN, transfile, 1000);
	// Get the number of species
	NM = mxGetScalar(prhs[2]);
	NREAC = mxGetScalar(prhs[3]);
	// Dynamic allocation (Matlab does not like this!)
	//YSP = calloc(NM, sizeof(double));
	//CGDOT = calloc(NM, sizeof(double));
	// The pressure and temperature in [Pa] and [K]
	PR = mxGetScalar(prhs[4]);
	TP = mxGetScalar(prhs[5]);
	// Get the species
	YSP = mxGetPr(prhs[6]);
	// Create the output matrix by getting the number of rows (m) and columns (n)
	m = mxGetM(prhs[6]);
	n = mxGetN(prhs[6]);
	plhs[0] = mxCreateDoubleMatrix(m,n,mxREAL);
	plhs[1] = mxCreateDoubleMatrix(1,NREAC,mxREAL);
	plhs[2] = mxCreateDoubleMatrix(1,NREAC,mxREAL);
	plhs[3] = mxCreateDoubleMatrix(1,1,mxREAL);
	plhs[4] = mxCreateDoubleMatrix(m,n,mxREAL);
	plhs[5] = mxCreateDoubleMatrix(m,n,mxREAL);
	plhs[6] = mxCreateDoubleMatrix(1,NREAC,mxREAL);
	// Call a pointer to the output matrix
	CGDOT = mxGetPr(plhs[0]);
	FWDK = mxGetPr(plhs[1]);
	REVK = mxGetPr(plhs[2]);
	GBMS = mxGetPr(plhs[3]);
	GML = mxGetPr(plhs[4]);
	GMS = mxGetPr(plhs[5]);
	EQKC = mxGetPr(plhs[6]);
	// We need to get some parameters of these files
	DKLEN(chemkinfile, &LENICK, &LENRCK, &LENCCK);
	DCLEN(transfile, &LENIMC, &LENRMC);
	// Dynamic allocation
	ICKWRK = calloc(LENICK, sizeof(int));
	RCKWRK = calloc(LENRCK, sizeof(double));
	IMCWRK = calloc(LENIMC, sizeof(int));
	RMCWRK = calloc(LENRMC, sizeof(double));
	// Now, we need to fill the chemkin arrays
	DEPKIN(chemkinfile, LENICK, LENRCK, LENCCK, ICKWRK, RCKWRK);
	DEPTRN(transfile, LENIMC, LENRMC, IMCWRK, RMCWRK);
	// OK, we are only using CHEMKIN to handle the chemical reactions 
	// In the CHEMKIN manual, this is CKWKP that returns the molar production rates
	// However, I converted this in my depkin.dll to DKWYP that returns [kg,species / m3 / s]
	// The input is pressure [Pa], Temperature [K], and the mass fractions of the species
	DKWYP(NM,LENICK,LENRCK,PR,TP,YSP,ICKWRK,RCKWRK,CGDOT);		// this returns wdot times the molecular weight
	// Get the forward and reverse reaction rates
	DKKFKR(NM,NREAC,LENICK,LENRCK,PR,TP,YSP,ICKWRK,RCKWRK,FWDK,REVK);
	// Get the Gibbs free energy in J/kg
	DKGBMS(NM,LENICK,LENRCK,PR,TP,YSP,ICKWRK,RCKWRK,GBMS);
	// Get the standard state Gibbs free energies in molar units
	DKGML(NM,LENICK,LENRCK,TP,ICKWRK,RCKWRK,GML);
	// Returns the standard state Gibbs free energies in mass units
	DKGMS(NM,TP,ICKWRK,RCKWRK,GMS);
	// Return the equilibrium constants for the reactions
	DKEQYP(NM,NREAC,LENICK,LENRCK,PR,TP,YSP,ICKWRK,RCKWRK,EQKC);
	// Memory clean-up
	free(ICKWRK); free(RCKWRK); free(IMCWRK); free(RMCWRK); 
	//free(FWDK); free(REVK);
	//free(YSP); free(CGDOT);		// Matlab does not like it if you do these as allocated dynamically
	// Return
}
