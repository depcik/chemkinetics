#if !defined(mexdepkin_h)
#define mexdepkin_h
	// Returns the array lengths for CHEMKIN
	__declspec(dllimport) void DKLEN(char depkin[1000], int *LENICK, int *LENRCK, int *LENCCK);
	// Returns the array lengths for Transport Properties
	__declspec(dllimport) void DCLEN(char deptrn[1000], int *LENIMC, int *LENRMC);
	// DEPKIN will return the work arrays for CHEMKIN
	__declspec(dllimport) void DEPKIN(char depkin[1000], int LENICK, int LENRCK, int LENCCK, int *ICKWRK, double *RCKWRK);
	// DEPTRN will return the work arrays for Transport Properties
	__declspec(dllimport) void DEPTRN(char deptrn[1000], int LENIMC, int LENRMC, int *IMCWRK, double *RMCWRK);
	// DKWYP will return the chemical species production/destruction rates
	__declspec(dllimport) void DKWYP(int NM, int LENICK, int LENRCK, double P, double T, double *Y, int *ICKWRK, double *RCKWRK, double *WDOT);
	// DKKFKR will return the forward and reverse reaction rates
	__declspec(dllimport) void DKKFKR(int NM, int NREAC, int LENICK, int LENRCK,
					double P, double T, double *X, int *ICKWRK, double *RCKWRK, double *FWDK, double *REVK);
	// DKGBMS will return the Gibbs free energy given the pressure, temperature, and mass fractions - J/kg
	__declspec(dllimport) void DKGBMS(int NM, int LENICK, int LENRCK, double P, double T, double *Y, int *ICKWRK, double *RCKWRK, double *G);
	// DKGML will return the standard state Gibbs free energies in molar units
	__declspec(dllimport) void DKGML(int NM, int LENICK, int LENRCK, double T, int *ICKWRK, double *RCKWRK, double *GML);
	// Returns  standard state Gibbs free energies of the species in mass units - J/kg
	__declspec(dllimport) void DKGMS(int NM, double T, int *ICKWRK, double *RCKWRK, double *G);
	// Return the Equilibrium constants of the reactions
	__declspec(dllimport) void DKEQYP(int NM, int NREAC, int LENICK, int LENRCK, double P, double T, double *Y, int *ICKWRK, double *RCKWRK, double *EQKC);

#endif // defined(mexdepkin_h)