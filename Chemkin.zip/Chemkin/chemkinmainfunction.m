% CHEMKIN RATE OF REACTION CALCULATOR FILE
% Copyright (C) 2019 Shah Saud Alam & Dr. Chris Depcik
% 
% This program is free software; you can redistribute it and/or modify it
% under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

% Author:
% Shah Saud Alam,
% Department of Mechanical Engineering,
% University of Kansas.

% Co-Author:
% Christopher Depcik [Dep-zik]
% Associate Professor and Graduate Director, Mechanical Engineering Department
% Courtesy Associate Professor, Aerospace Engineering Department
% 3144C Learned Hall, 1530 W. 15th Street, Lawrence, KS 66045-7609
% University of Kansas (KU), Ph: (785) 864-4151, Fax: (785) 864-5254
% depcik@ku.edu, http://depcik.faculty.ku.edu, He/Him/His

% Created: 09-15-2017
% Updated: 06-18-2019

function WdotM=chemkinmainfunction(PR,TP,NM,Y)

% Here are the CHEMKIN needed files that include the reaction mechanism
chemkin = ('Mueller1999.asc');
transport = ('Mueller1999_tran.asc');

% Number of reactions
NREAC = 21;

% Call the mexfile that is the wrapper around CHEMKIN
% This will return the chemical species production and destruction rates in
% the order above (H2, H...) as [kg/m3/s]. In my notes, this is wdot *
% molecular weight. So, in other words, if you divide by the density you
% will get the chemical species production and destruction rates as [1/s]
% or the change in mass fraction per time (this is my derived chemical
% species ODE)
[WdotM, FWDK, REVK, GBMS, GML, GMS, EQYP] = mexdepkin(chemkin,transport,NM,NREAC,PR,TP,Y);
% GBMS returns as J/kg; uses mass fractions
% GML returns array as J/kmol
% GMS returns array as J/kg
% EQYP returns array ad [mol/cm^3]**power